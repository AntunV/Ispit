﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IspitModel.Model
{
    public class Ucenik
    {






        public string Ime { get; set; }

        public string Prezime { get; set; }

        public DateTime DatumRodjenja { get; set; }

        public double Prosjek { get; set; }


        public int Starost(DateTime datumRodjenja)
        {
            
            
            int starost = DateTime.Now.Year - datumRodjenja.Year;
            Console.WriteLine($"Ucenik je star :  {starost} ");

            return starost;



        }

        public Ucenik UnesiPodatkeOUceniku()
        {
            Console.WriteLine("Unesi ime");
            string ime = Console.ReadLine();
            Console.WriteLine("Unesi prezime");
            string prezime = Console.ReadLine();
            Console.WriteLine("Unesi datum rodjenja");
            DateTime datumRodjenja = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Unesi prosjek");
            double prosjek = double.Parse(Console.ReadLine());

            return new Ucenik
            {
                Ime = ime,
                Prezime = prezime,
                DatumRodjenja = datumRodjenja,
                Prosjek = prosjek
            };


        }

        public void IspisProsjeka(double prosjekUcenika)
        {
            if (prosjekUcenika >= 0 && prosjekUcenika <= 1.49)
            {
                Console.WriteLine("Ucenik je dobio nedovoljnu ocjenu");
            }
            else if (prosjekUcenika >= 1.50 && prosjekUcenika <= 2.49)
            {
                Console.WriteLine("Ucenik je dobio ocjenu dovoljan");
            }
            else if (prosjekUcenika >= 2.50 && prosjekUcenika <= 3.49)
            {
                Console.WriteLine("Ucenik je dobio ocjenu dobar");
            }
            else if (prosjekUcenika >= 3.50 && prosjekUcenika <= 4.49)
            {
                Console.WriteLine("Ucenik je dobio ocjenu vrlo dobar");
            }
            else if (prosjekUcenika >= 4.50 && prosjekUcenika <= 5)
            {
                Console.WriteLine("Ucenik je dobio ocjenu odlican");
            }
            else
            {
                Console.WriteLine("Unjeli ste pogresan prosjek");
            }
        }





    }



















}






