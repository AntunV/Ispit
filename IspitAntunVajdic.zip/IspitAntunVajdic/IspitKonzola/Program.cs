﻿using IspitModel.Model;


Ucenik ucenik = new Ucenik();
Console.WriteLine("Koliko zelis ucenika upisati");
int brojUcenika = int.Parse(Console.ReadLine());
if(brojUcenika < 0)
{
    return;
}

Console.WriteLine("*************");

List<Ucenik> ucenici = new List<Ucenik>();
for (int i = 0; i < brojUcenika; i++)
{
    Console.WriteLine($"Unesi broj ucenika {i + 1}");
    Console.WriteLine("************");
    ucenici.Add(ucenik.UnesiPodatkeOUceniku());
}
foreach (var ucenik1  in ucenici)
{
    Console.WriteLine($"Ime ucenika je :  {ucenik1.Ime}");
    Console.WriteLine($"Prezime ucenika je : {ucenik1.Prezime} ");
    ucenik.Starost(ucenik1.DatumRodjenja);
    ucenik.IspisProsjeka(ucenik1.Prosjek);


}